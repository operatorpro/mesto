// теперь картинки можно импортировать,
// вебпак добавит в переменные правильные пути
import './pages/index.css';
import './scripts/index.js';